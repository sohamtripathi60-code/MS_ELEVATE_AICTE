import pandas as pd
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(BASE_DIR, "data", "dataset.csv")

df = pd.read_csv(file_path)

le = LabelEncoder()
df['stress_level'] = le.fit_transform(df['stress_level'])

X = df[['study_hours', 'sleep_hours', 'screen_time', 'exam_pressure']]
y = df['stress_level']

model = RandomForestClassifier()
model.fit(X, y)

def predict_stress(input_data):
    prediction = model.predict([input_data])[0]
    confidence = max(model.predict_proba([input_data])[0]) * 100
    return le.inverse_transform([prediction])[0], round(confidence, 2)
