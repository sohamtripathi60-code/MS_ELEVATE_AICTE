import streamlit as st
import matplotlib.pyplot as plt
from model import predict_stress

st.set_page_config(page_title="Student Stress Prediction Dashboard")

st.title("📊 Student Stress Prediction Dashboard")
st.write("Predict student stress level using Machine Learning")

study_hours = st.slider("Study Hours per Day", 0, 12, 4)
sleep_hours = st.slider("Sleep Hours per Day", 0, 12, 7)
screen_time = st.slider("Screen Time (Hours)", 0, 12, 4)
exam_pressure = st.slider("Exam Pressure (1-10)", 1, 10, 5)

if st.button("Predict Stress Level"):

    input_data = [study_hours, sleep_hours, screen_time, exam_pressure]
    stress, confidence = predict_stress(input_data)

    st.subheader(f"Predicted Stress Level: {stress}")
    st.write(f"Model Confidence: {confidence}%")

    fig = plt.figure()
    values = [study_hours, sleep_hours, screen_time, exam_pressure]
    labels = ['Study', 'Sleep', 'Screen', 'Pressure']
    plt.bar(labels, values)
    plt.title("Your Input Overview")
    st.pyplot(fig)
