# Student Stress Prediction Dashboard

This project predicts student stress levels using Machine Learning.

## Run the Project

1. Install dependencies:
   pip install -r requirements.txt

2. Run the app:
   streamlit run app.py
